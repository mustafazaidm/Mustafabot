<?
// Yassinox Botnet Configuration File \\
$installed = 0; // If You See This Command, Please Change 0 to 1
// Let's move Now To Mysql Configuration !
$usernamedb = "root"; // Just Put Your Mysql Username
$passworddb = "12345678"; // Just Put Your Mysql Password
$hostdb = "localhost"; // I think It's For Mysql Hostname
$db = "bot"; // Just Fill The Database Name Here
// Do I Need To Login ? Yes i need
$usernamec = "mustafa"; // Put The Prefered Username
$passwordc = "mustafa"; // Just put A Strong Password
$security_token = "MAKE A RANDOM STRING FOR YOUR TOKEN"; // This Is Will Be Your Session Token !
// And, That's All !
?>