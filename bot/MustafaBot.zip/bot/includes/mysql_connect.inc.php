<?
include("configuration.inc.php");
$connect = mysql_connect($hostdb,$usernamedb,$passworddb);
$selectdb = mysql_select_db($db);
?>