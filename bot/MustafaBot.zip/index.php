<title>Mustafa Riadh</title>
<div id="z">
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<br><br><br><br><br><br><br><br><br><br><br>
<font size=36>  
<center>
<font color="blue">
Welcome To My Bot
<br>
Mustafa Riadh Ketab
</center>
<center>
<br>

<a class="login_title"><font color="red">Go To Main Panel</a>
<form action="bot/index.php" method="post">
<input type="submit" name="submit" class="login_submit" value="Enter&nbsp;">
</center>
</div>